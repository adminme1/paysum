<!-- menu-size will be the dimension of your menu. If you set it to smaller than your content it will scroll-->
<div class="menu-size" style="width:230px;">
    <!-- Menu Title-->
    <div class="pt-3">
        <div class="page-title sidebar-title d-flex">
            <div class="align-self-center me-auto">
                <p class="color-highlight">Welcome Back</p>
                <h1>PAYSUM</h1>
            </div>
            <div class="align-self-center ms-auto">
                <!-- <a href="#"
                data-bs-toggle="dropdown"
                class="icon gradient-blue shadow-bg shadow-bg-s rounded-m">
                    <img src="images/pictures/25s.jpg" width="45" class="rounded-m" alt="img">
                </a> -->
                <!-- Menu Title Dropdown Menu-->
                <!-- <div class="dropdown-menu">
                    <div class="card card-style shadow-m mt-1 me-1">
                        <div class="list-group list-custom list-group-s list-group-flush rounded-xs px-3 py-1">
                            <a href="page-wallet.html" class="list-group-item">
                                <i class="has-bg gradient-green shadow-bg shadow-bg-xs color-white rounded-xs bi bi-credit-card"></i>
                                <strong class="font-13">Wallet</strong>
                            </a>
                            <a href="page-activity.html" class="list-group-item">
                                <i class="has-bg gradient-blue shadow-bg shadow-bg-xs color-white rounded-xs bi bi-graph-up"></i>
                                <strong class="font-13">Activity</strong>
                            </a>
                            <a href="page-profile.html" class="list-group-item">
                                <i class="has-bg gradient-yellow shadow-bg shadow-bg-xs color-white rounded-xs bi bi-person-circle"></i>
                                <strong class="font-13">Account</strong>
                            </a>
                            <a href="page-signin-1.html" class="list-group-item">
                                <i class="has-bg gradient-red shadow-bg shadow-bg-xs color-white rounded-xs bi bi-power"></i>
                                <strong class="font-13">Log Out</strong>
                            </a>
                        </div>
                    </div>
                </div> -->
            </div>
        </div>

        <div class="divider divider-margins mb-3 opacity-50"></div>

        <!-- Main Menu List-->
        <div class="list-group list-custom list-menu-large">
            <!-- <a href="index-waves.html" id="nav-welcome" class="list-group-item">
                <i class="bi bg-red-dark shadow-bg shadow-bg-xs bi-heart-fill"></i>
                <div>Welcome</div>
                <i class="bi bi-chevron-right"></i>
            </a>
            <a href="pages.html" id="nav-pages" class="list-group-item">
                <i class="bi bg-green-dark shadow-bg shadow-bg-xs bi-star-fill"></i>
                <div>Page Packs</div>
                <i class="bi bi-chevron-right"></i>
            </a>
            <a href="#" id="nav-homes" data-submenu="sub1" class="list-group-item">
                <i class="bi bg-blue-dark shadow-bg shadow-bg-xs bi-house-fill"></i>
                <div>Home Styles</div>
                <i class="bi bi-plus font-18"></i>
            </a>
            <div class="list-submenu" id="sub1">
                <a href="index-waves.html" id="nav-waves" class="list-group-item">
                    <div class="ps-4">Waves</div>
                    <i class="bi bi-chevron-right"></i>
                </a>
                <a href="index.html" id="nav-classic" class="list-group-item">
                    <div class="ps-4">Classic</div>
                    <i class="bi bi-chevron-right"></i>
                </a>
            </div>
            <a href="components.html" id="nav-comps" class="list-group-item">
                <i class="bi bg-brown-dark shadow-bg shadow-bg-xs bi-gear-wide-connected"></i>
                <div>Components</div>
                <i class="bi bi-chevron-right"></i>
            </a> -->
			<a data-bs-toggle="offcanvas" data-bs-target="#menu-highlights" href="#" class="list-group-item">
				<i class="bi bg-magenta-dark shadow-bg shadow-bg-xs bi-droplet"></i>
				<div>Color Theme</div>
				<i class="bi bi-chevron-right"></i>
			</a>

            <a href="#" class="list-group-item" data-toggle-theme data-trigger-switch="switch-1">
                <i class="bi bg-yellow-dark shadow-bg shadow-bg-xs bi-lightbulb-fill"></i>
                <div>Dark Mode</div>
                <div class="form-switch ios-switch switch-green switch-s me-2">
                    <input type="checkbox" data-toggle-theme class="ios-input" id="switch-1">
                    <label class="custom-control-label" for="switch-1"></label>
                </div>
            </a>
        </div>

        <div class="divider divider-margins mb-3 opacity-50"></div>

        <!-- Quick Actions Icons-->
        <!-- <div class="content pt-1">
            <div class="d-flex text-center">
                <div class="me-auto">
                    <a href="page-payment-transfer.html" class="icon icon-s rounded-s gradient-red shadow-bg shadow-bg-xs"><i class="font-16 color-white bi bi-arrow-up"></i></a>
                    <h6 class="font-11 font-400 opacity-70 mb-n1 pt-2">Transfer</h6>
                </div>
                <div class="m-auto">
                    <a href="page-payment-request.html" class="icon icon-s rounded-s gradient-green shadow-bg shadow-bg-xs"><i class="font-16 color-white bi bi-arrow-down"></i></a>
                    <h6 class="font-11 font-400 opacity-70 mb-n1 pt-2">Request</h6>
                </div>
                <div class="ms-auto">
                    <a href="page-payment-exchange.html" class="icon icon-s rounded-s gradient-blue shadow-bg shadow-bg-xs"><i class="font-16 color-white bi bi-arrow-left-right"></i></a>
                    <h6 class="font-11 font-400 opacity-70 mb-n1 pt-2">Exchange</h6>
                </div>
            </div>
        </div> -->


        <div class="divider divider-margins opacity-50"></div>

        <!-- Useful Links-->
        <h6 class="opacity-40 px-3 mt-n2 mb-0">Useful Links</h6>
        <div class="list-group list-custom list-menu-small">
            <a href="tel:+1 234 567 8091" class="list-group-item default-link">
                <i class="bi bi-arrow-up-circle-fill opacity-20 font-16"></i>
                <div>Support</div>
                <i class="bi bi-chevron-right"></i>
            </a>
            <a href="profile.php" class="list-group-item">
                <i class="bi bi-person-circle opacity-20 font-16"></i>
                <div>Account</div>
                <i class="bi bi-chevron-right"></i>
            </a>
            <a href="logout.php" class="list-group-item">
                <i class="bi bi-bar-chart-fill opacity-20 font-16"></i>
                <div>Log Out</div>
                <i class="bi bi-chevron-right"></i>
            </a>
        </div>

        <div class="divider divider-margins opacity-50"></div>
        <!-- Menu Copyright -->
        <p class="px-3 font-9 opacity-30 color-theme mt-n3">Copyright <span class="copyright-year"></span>. Made with <i class="bi bi-heart-fill color-red-dark px-1"></i> by CRISIS Entertainment</p>
    </div>
</div>
