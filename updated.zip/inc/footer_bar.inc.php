<div id="footer-bar" class="footer-bar-1 footer-bar-detached">
    <!-- <a href="page-wallet.html"><i class="bi bi-wallet2"></i><span>Cards</span></a> -->
    <a href="wallet.php"><i class="bi bi-credit-card"></i><span>Wallet</span></a>
    <!-- <a href="activity.php"><i class="bi bi-graph-up"></i><span>Activity</span></a> -->
    <a href="index.php" class="circle-nav-2"><i class="bi bi-house-fill"></i><span>Home</span></a>
    <!-- <a href="page-payments.html"><i class="bi bi-receipt"></i><span>Payments</span></a> -->
    <a href="#" data-bs-toggle="offcanvas" data-bs-target="#menu-sidebar"><i class="bi bi-three-dots"></i><span>More</span></a>
</div>